import React, { useEffect, useMemo, useState } from "react";

/**
 * Uses endpoints from backend folder :
 *  GET /api/health
 *  GET /api/tables/summary
 *  GET /api/menu
 *  GET /api/tables/:id/current
 *  POST /api/tables/:id/order   { items:[{food_id, quantity}], employee_id? }
 */

const styles = `
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;background:linear-gradient(135deg,#f5f7fa 0%,#e9ecef 100%);min-height:100vh;padding:20px}
.container{max-width:1400px;margin:0 auto}
.header{background:#fff;padding:24px 32px;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.08);margin-bottom:24px;display:flex;justify-content:space-between;align-items:center}
.logo-section{display:flex;align-items:center;gap:16px}
.logo{width:52px;height:52px;background:linear-gradient(135deg,#ef4444 0%,#dc2626 100%);border-radius:12px;color:#fff;font-weight:700;font-size:28px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(239,68,68,.3)}
.logo-text h1{font-size:24px;color:#1a1a1a;font-weight:700;margin-bottom:4px}
.logo-text p{font-size:13px;color:#666}
.api-status{display:flex;align-items:center;gap:8px;padding:8px 16px;background:#d1fae5;border-radius:8px;font-size:14px;font-weight:600;color:#065f46}
.api-status.disconnected{background:#fecaca;color:#7f1d1d}
.api-status-dot{width:8px;height:8px;border-radius:50%;background:#10b981;animation:pulse-green 2s infinite}
.api-status.disconnected .api-status-dot{background:#ef4444;animation:pulse-red 2s infinite}
.header-buttons{display:flex;gap:12px}
.btn{padding:12px 24px;border-radius:10px;border:none;font-weight:600;cursor:pointer;transition:all .3s ease;font-size:14px}
.btn-primary{background:#ef4444;color:#fff}
.btn-primary:hover{background:#dc2626;transform:translateY(-2px);box-shadow:0 6px 16px rgba(239,68,68,.3)}
.btn-secondary{background:#f3f4f6;color:#1a1a1a;border:2px solid #e5e7eb}
.btn-secondary:hover{background:#e5e7eb;border-color:#d1d5db}
.btn:disabled{opacity:.5;cursor:not-allowed}

.stats-section{background:#fff;padding:28px 32px;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.08);margin-bottom:24px}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px}
.stat-card{padding:20px;border-radius:12px;border:2px solid #f0f0f0;transition:all .3s ease;background:#fafafa}
.stat-label{font-size:12px;color:#666;margin-bottom:8px;text-transform:uppercase;letter-spacing:.8px;font-weight:600}
.stat-value{font-size:36px;font-weight:700;color:#1a1a1a;display:flex;align-items:center;gap:8px}
.stat-icon{width:12px;height:12px;border-radius:50%}
.stat-card.available .stat-icon{background:#10b981}
.stat-card.occupied .stat-icon{background:#ef4444}
.stat-card.reserved .stat-icon{background:#f59e0b}
.stat-card.revenue .stat-icon{background:#8b5cf6}

.tables-section{background:#fff;padding:32px;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.08)}
.section-header{margin-bottom:28px;padding-bottom:20px;border-bottom:2px solid #f0f0f0}
.section-title{font-size:20px;font-weight:700;color:#1a1a1a}
.tables-container{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:28px;padding:8px}
.table-card{aspect-ratio:1;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;transition:all .3s ease;position:relative;padding:24px;box-shadow:0 8px 16px rgba(0,0,0,.12)}
.table-card.available{background:linear-gradient(135deg,#e8f5e9 0%,#c8e6c9 100%);border:4px solid #4caf50}
.table-card.occupied{background:linear-gradient(135deg,#ffebee 0%,#ffcdd2 100%);border:4px solid #f44336}
.status-indicator{width:14px;height:14px;border-radius:50%;position:absolute;top:16px;right:16px;z-index:2;border:3px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.25)}
.status-indicator.available{background:#4caf50;animation:pulse-green 2s infinite}
.status-indicator.occupied{background:#f44336;animation:pulse-red 2s infinite}
@keyframes pulse-green{0%,100%{box-shadow:0 0 0 0 rgba(76,175,80,.7)}50%{box-shadow:0 0 0 10px rgba(76,175,80,0)}}
@keyframes pulse-red{0%,100%{box-shadow:0 0 0 0 rgba(244,67,54,.7)}50%{box-shadow:0 0 0 10px rgba(244,67,54,0)}}
.table-name{font-size:22px;font-weight:700;color:#1a1a1a;margin-bottom:12px}
.table-info{font-size:14px;color:#666;margin-bottom:6px}
.table-amount{font-size:20px;font-weight:700;color:#1a1a1a;margin-top:8px}
.status-badge{font-size:11px;padding:6px 14px;border-radius:14px;font-weight:600;text-transform:uppercase;letter-spacing:.6px;margin-top:12px}
.status-badge.available{background:#4caf50;color:#fff}
.status-badge.occupied{background:#f44336;color:#fff}

.loading{display:flex;justify-content:center;align-items:center;padding:60px;font-size:18px;color:#666}
.spinner{display:inline-block;width:40px;height:40px;border:4px solid #f3f3f3;border-top:4px solid #ef4444;border-radius:50%;animation:spin 1s linear infinite;margin-right:16px}
@keyframes spin{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}
.error-message{background:#fecaca;color:#7f1d1d;padding:16px 24px;border-radius:12px;margin-bottom:20px;border-left:4px solid #ef4444;font-weight:600}
.success-message{background:#d1fae5;color:#065f46;padding:16px 24px;border-radius:12px;margin-bottom:20px;border-left:4px solid #10b981;font-weight:600}

.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:1000}
.modal{background:#fff;border-radius:20px;max-width:1100px;width:95%;max-height:90vh;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.3);display:flex;flex-direction:column}
.modal-header{padding:24px 32px;border-bottom:2px solid #f0f0f0;display:flex;justify-content:space-between;align-items:center;background:#fafafa}
.modal-title{font-size:24px;font-weight:700;color:#1a1a1a}
.modal-subtitle{font-size:14px;color:#666;margin-top:4px}
.close-btn{background:#f3f4f6;border:none;width:36px;height:36px;border-radius:50%;cursor:pointer;font-size:20px;color:#666;display:flex;align-items:center;justify-content:center}
.modal-body{display:grid;grid-template-columns:2fr 1fr;gap:24px;padding:24px;overflow:auto}
.menu-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}
.menu-card{border:2px solid #f0f0f0;border-radius:12px;padding:16px;background:#fff}
.menu-title{font-weight:700;margin-bottom:4px}
.menu-cat{font-size:12px;color:#666;margin-bottom:8px}
.menu-price{font-weight:700;color:#ef4444;margin-bottom:10px}
.menu-actions{display:flex;gap:10px}
.side-panel{border-left:2px solid #f0f0f0;padding-left:16px}
.panel-block{background:#fafafa;border:2px solid #f0f0f0;border-radius:12px;padding:16px;margin-bottom:16px}
.block-title{font-weight:700;margin-bottom:8px}
.item-row{display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px dashed #e5e7eb}
.qty-btn{width:28px;height:28px;border:2px solid #ef4444;background:#fff;color:#ef4444;border-radius:50%;font-weight:700}
.total-row{display:flex;justify-content:space-between;font-weight:700;margin-top:10px}
.action-row{display:flex;gap:10px;margin-top:12px}
@media(max-width:900px){.modal-body{grid-template-columns:1fr}}
`;

export default function App() {
  const [apiConnected, setApiConnected] = useState(null);
  const [tables, setTables] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);

  const [show, setShow] = useState(false);
  const [selectedTable, setSelectedTable] = useState(null);

  const [menu, setMenu] = useState([]);
  const [menuLoading, setMenuLoading] = useState(false);
  const [current, setCurrent] = useState({ orderId: null, items: [], total: 0, itemCount: 0 });

  const [cart, setCart] = useState([]);
  const cartTotal = useMemo(() => cart.reduce((s, i) => s + i.price * i.quantity, 0), [cart]);

  const fetchTables = async () => {
    setLoading(true);
    setErr(null);
    try {
      const h = await fetch("/api/health");
      setApiConnected(h.ok);
      const r = await fetch("/api/tables/summary");
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const summary = await r.json();
      const normalized = (summary || []).map(t => ({
        id: t.table,
        name: `Table ${t.table}`,
        status: t.status,
        items: t.orderCount || 0,
        amount: Number(t.total || 0),
      }));
      setTables(normalized);
    } catch (e) {
      setErr(e.message || "Failed to load");
      setTables([]);
      setApiConnected(false);
    } finally {
      setLoading(false);
    }
  };

  const fetchMenu = async () => {
    setMenuLoading(true);
    try {
      const r = await fetch("/api/menu");
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      const normalized = (data || []).map(it => ({
        id: it.id ?? it.food_id ?? null,
        name: it.name ?? it.food_name ?? "Menu",
        price: Number(it.price ?? it.food_cost ?? 0),
        category: it.category ?? "Menu",
      }));
      setMenu(normalized);
    } catch (e) {
      console.error(e);
      setMenu([]);
    } finally {
      setMenuLoading(false);
    }
  };

  const fetchCurrent = async (tableId) => {
    try {
      const r = await fetch(`/api/tables/${tableId}/current`);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      setCurrent({
        orderId: data.orderId,
        items: data.items || [],
        total: Number(data.total || 0),
        itemCount: Number(data.itemCount || 0),
      });
    } catch (e) {
      console.error(e);
      setCurrent({ orderId: null, items: [], total: 0, itemCount: 0 });
    }
  };

  useEffect(() => {
    fetchTables();
    const id = setInterval(fetchTables, 30000);
    return () => clearInterval(id);
  }, []);

  const openTable = async (t) => {
    setSelectedTable(t);
    setCart([]);
    setShow(true);
    await Promise.all([fetchMenu(), fetchCurrent(t.id)]);
  };

  const closeModal = () => {
    setShow(false);
    setSelectedTable(null);
    setCart([]);
  };

  const addToCart = (m) => {
    setCart(prev => {
      const found = prev.find(it => it.id === m.id);
      if (found) return prev.map(it => it.id === m.id ? { ...it, quantity: it.quantity + 1 } : it);
      return [...prev, { id: m.id, name: m.name, price: m.price, quantity: 1 }];
    });
  };
  const changeQty = (id, d) => {
    setCart(prev =>
      prev
        .map(it => it.id === id ? { ...it, quantity: Math.max(0, it.quantity + d) } : it)
        .filter(it => it.quantity > 0)
    );
  };

  const submitOrder = async () => {
    if (!selectedTable || cart.length === 0) return;
    try {
      const payload = {
        items: cart.map(c => ({ food_id: c.id, quantity: c.quantity })),
        employee_id: 1,
      };
      const r = await fetch(`/api/tables/${selectedTable.id}/order`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!r.ok) {
        const j = await r.json().catch(() => ({}));
        throw new Error(j.error || `HTTP ${r.status}`);
      }
      await Promise.all([fetchCurrent(selectedTable.id), fetchTables()]);
      setCart([]);
    } catch (e) {
      alert(`Failed to submit order: ${e.message}`);
    }
  };

  const stats = useMemo(() => {
    const s = { available: 0, occupied: 0, reserved: 0, totalRevenue: 0 };
    tables.forEach(t => {
      const st = (t.status || '').toLowerCase();
      if (st === 'available') s.available++;
      else if (st === 'occupied') { s.occupied++; s.totalRevenue += Number(t.amount || 0); }
      else s.reserved++;
    });
    return s;
  }, [tables]);

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: styles }} />
      <div className="container">
        {/* Header */}
        <div className="header">
          <div className="logo-section">
            <div className="logo">CC</div>
            <div className="logo-text">
              <h1>Cloud Chef POS</h1>
              <p>Sushi Restaurant Management System</p>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div className={`api-status ${apiConnected === false ? "disconnected" : ""}`}>
              <div className="api-status-dot" />
              <span>{apiConnected === null ? "Checking API…" : apiConnected ? "API Connected" : "API Disconnected"}</span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="stats-section">
          <div className="stats-grid">
            <div className="stat-card available">
              <div className="stat-label">AVAILABLE</div>
              <div className="stat-value"><span className="stat-icon" />{stats.available}</div>
            </div>
            <div className="stat-card occupied">
              <div className="stat-label">OCCUPIED</div>
              <div className="stat-value"><span className="stat-icon" />{stats.occupied}</div>
            </div>
            <div className="stat-card reserved">
              <div className="stat-label">RESERVED</div>
              <div className="stat-value"><span className="stat-icon" />{stats.reserved}</div>
            </div>
            <div className="stat-card revenue">
              <div className="stat-label">TOTAL REVENUE</div>
              <div className="stat-value"><span className="stat-icon" />${stats.totalRevenue.toFixed(2)}</div>
            </div>
          </div>
        </div>

        {/* Tables */}
        <div className="tables-section">
          <div className="section-header"><h2 className="section-title">Restaurant Tables</h2></div>
          {err && <div className="error-message">Error: {err}</div>}
          <div className="tables-container">
            {loading ? (
              <div className="loading"><div className="spinner" /><span>Loading tables…</span></div>
            ) : (
              tables.map((t) => {
                const st = (t.status || '').toLowerCase();
                return (
                  <div
                    key={t.id}
                    className={`table-card ${st}`}
                    onClick={() => openTable(t)}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => e.key === "Enter" && openTable(t)}
                  >
                    <div className={`status-indicator ${st}`} />
                    <div className="table-name">{t.name}</div>
                    <div className="table-info">{t.items} items</div>
                    <div className="table-amount">${Number(t.amount || 0).toFixed(2)}</div>
                    <div className={`status-badge ${st}`}>{String(t.status || '').toUpperCase()}</div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Modal */}
        {show && selectedTable && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <div>
                  <div className="modal-title">{selectedTable.name} - Menu</div>
                  <div className="modal-subtitle">
                    {(selectedTable.status || '')} • {current.itemCount} items • ${Number(current.total || 0).toFixed(2)}
                  </div>
                </div>
                <button className="close-btn" onClick={closeModal}>×</button>
              </div>

              <div className="modal-body">
                {/* Menu grid */}
                <div>
                  {menuLoading ? (
                    <div className="loading"><div className="spinner" /><span>Loading menu…</span></div>
                  ) : (
                    <div className="menu-grid">
                      {menu.map(m => (
                        <div key={m.id} className="menu-card">
                          <div className="menu-title">{m.name}</div>
                          <div className="menu-cat">{m.category}</div>
                          <div className="menu-price">${m.price.toFixed(2)}</div>
                          <div className="menu-actions">
                            <button className="btn btn-primary" onClick={() => addToCart(m)}>Add to Order</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Right side: current & cart */}
                <div className="side-panel">
                  <div className="panel-block">
                    <div className="block-title">Already Ordered</div>
                    {current.items.length === 0 ? (
                      <div style={{ color: '#666' }}>No previous items</div>
                    ) : (
                      <>
                        {current.items.map((it) => (
                          <div key={it.food_id} className="item-row">
                            <div>{it.name} x {it.quantity}</div>
                            <div>${Number(it.lineTotal).toFixed(2)}</div>
                          </div>
                        ))}
                        <div className="total-row"><span>Total</span><span>${Number(current.total || 0).toFixed(2)}</span></div>
                      </>
                    )}
                  </div>

                  <div className="panel-block">
                    <div className="block-title">Add More Items</div>
                    {cart.length === 0 ? (
                      <div style={{ color: '#666' }}>No items selected</div>
                    ) : (
                      <>
                        {cart.map((c) => (
                          <div key={c.id} className="item-row">
                            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                              <button className="qty-btn" onClick={() => changeQty(c.id, -1)}>−</button>
                              <div>{c.name} x {c.quantity}</div>
                              <button className="qty-btn" onClick={() => changeQty(c.id, 1)}>+</button>
                            </div>
                            <div>${(c.price * c.quantity).toFixed(2)}</div>
                          </div>
                        ))}
                        <div className="total-row"><span>Total</span><span>${cartTotal.toFixed(2)}</span></div>
                        <div className="action-row">
                          <button className="btn btn-secondary" onClick={() => setCart([])}>Clear</button>
                          <button className="btn btn-primary" onClick={submitOrder}>Submit Order</button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}