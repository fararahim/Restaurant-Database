# 4523-Final-Project
This is a repo where the members are working on creating a resteraunt Point of Sale website that will be hosted on the cloud.

Member names:
1) Christian Hall
2) Yechan Kim
3) Chase Stephens
4) Fariza Abdurakhimova
5) Alyssa Moore
