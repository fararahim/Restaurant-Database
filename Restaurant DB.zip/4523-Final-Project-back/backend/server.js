const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

/// cd backend -> npm install to get dependencies and add .env file into backend folder as well with provided RDS info
/// Usage: cd into backend folder and run "npm start" or "node server.js" both work. --> will go to "localhost:5000"
/// To see the tables, change URL to { localhost:5000/api/[the table you are wanting to view]}
/// Example: "localhost:5000/api/orders"  "localhost:5000/api/employees" "localhost:5000/api/top"

// Middleware

app.use(cors());
app.use(express.json());

// Database connection configuration for AWS RDS
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'restaurantPOS',
  port: Number(process.env.DB_PORT || 3306),
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
};



const pool = mysql.createPool(dbConfig);
const dbp = pool.promise();

(async () => {
  try {
    await dbp.query('SELECT 1');
    console.log('✅ Connected to MySQL');
  } catch (e) {
    console.error('❌ MySQL connection failed:', e.message);
  }
})();

// Health check 
app.get('/api/health', (_req, res) => res.json({ ok: true }));

//  menu(food_id, food_name, food_cost)
app.get('/api/menu', async (_req, res) => {
  try {
    const [rows] = await dbp.query(`
      SELECT food_id AS id, food_name AS name, food_cost AS price
      FROM menu
      ORDER BY food_id
    `);
    const data = rows.map(r => ({
      id: r.id,
      name: r.name,
      price: Number(r.price || 0),
      category: 'Menu', 
    }));
    res.json(data);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message || 'Server error' });
  }
});

// TABLES SUMMARY fill with current order's items & total.
app.get('/api/tables/summary', async (_req, res) => {
  try {
    // Current links table -> order
    const [current] = await dbp.query(
      'SELECT top_id, order_id FROM top WHERE isCurrent = TRUE'
    );

    const currentByTop = {};
    for (const r of current) currentByTop[r.top_id] = r.order_id;

    // Aggregate for ALL orders 
    const [agg] = await dbp.query(`
      SELECT mo.order_id,
             SUM(mo.quantity)                               AS items,
             SUM(mo.quantity * m.food_cost)                 AS total
      FROM menu_orders mo
      JOIN menu m ON m.food_id = mo.food_id
      GROUP BY mo.order_id
    `);
    const byOrder = Object.create(null);
    for (const a of agg) {
      byOrder[a.order_id] = {
        items: Number(a.items || 0),
        total: Number(a.total || 0),
      };
    }

    const TABLE_COUNT = 8; 
    const out = [];
    for (let t = 1; t <= TABLE_COUNT; t += 1) {
      const orderId = currentByTop[t] || null;
      const occupied = Boolean(orderId);
      const s = orderId ? (byOrder[orderId] || { items: 0, total: 0 }) : { items: 0, total: 0 };
      out.push({
        table: t,
        status: occupied ? 'occupied' : 'available',
        orderId,
        orderCount: s.items,
        total: Number(s.total.toFixed(2)), 
      });
    }

    res.json(out);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message || 'Server error' });
  }
});

// Current Order:  { orderId, items:[{food_id,name,quantity,lineTotal}], total, itemCount }
app.get('/api/tables/:id/current', async (req, res) => {
  const tableId = Number(req.params.id);
  try {
    const [link] = await dbp.query(
      'SELECT order_id FROM top WHERE top_id = ? AND isCurrent = TRUE',
      [tableId]
    );
    if (!link.length) {
      return res.json({ orderId: null, items: [], total: 0, itemCount: 0 });
    }
    const orderId = link[0].order_id;

    const [lines] = await dbp.query(`
      SELECT mo.food_id, mo.quantity, m.food_name AS name, m.food_cost AS price
      FROM menu_orders mo
      JOIN menu m ON m.food_id = mo.food_id
      WHERE mo.order_id = ?
      ORDER BY mo.food_id
    `, [orderId]);

    let total = 0, count = 0;
    const items = lines.map(l => {
      const lineTotal = Number(l.price) * Number(l.quantity);
      total += lineTotal;
      count += Number(l.quantity);
      return {
        food_id: l.food_id,
        name: l.name,
        quantity: Number(l.quantity),
        lineTotal,
      };
    });

    res.json({
      orderId,
      items,
      total: Number(total.toFixed(2)), 
      itemCount: count,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message || 'Server error' });
  }
});

// Submit order it returns body: { items:[{food_id, quantity}], employee_id? }
app.post('/api/tables/:id/order', async (req, res) => {
  const tableId = Number(req.params.id);
  const { items = [], employee_id = 1089 } = req.body;

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'No items to add' });
  }

  const conn = await pool.promise().getConnection();
  try {
    await conn.beginTransaction();

    // lock current mapping for this table 
    const [cur] = await conn.query(
      'SELECT order_id FROM top WHERE top_id = ? AND isCurrent = TRUE FOR UPDATE',
      [tableId]
    );

    let orderId;
    if (cur.length) {
      orderId = cur[0].order_id; // append to the current order
    } else {
      // Create new order row using the order schema 
      const [ins] = await conn.query(
        'INSERT INTO orders (employee, top_id, tip) VALUES (?, ?, ?)',
        [employee_id, tableId, 0]
      );
      orderId = ins.insertId;

      // Close any previous current rows for this table and insert a new "current" row
      await conn.query('UPDATE top SET isCurrent = FALSE WHERE top_id = ?', [tableId]);
      await conn.query(
        'INSERT INTO top (top_id, order_id, isCurrent) VALUES (?,?,TRUE)',
        [tableId, orderId]
      );
    }

    // Upsert items into menu_orders (PK = (order_id, food_id))
    for (const it of items) {
      const foodId = Number(it.food_id);
      const qty = Number(it.quantity);
      if (!foodId || !qty) continue;

      await conn.query(
        `INSERT INTO menu_orders (order_id, food_id, quantity)
         VALUES (?,?,?)
         ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)`,
        [orderId, foodId, qty]
      );
    }

    // Compute new untaxed total to return
    const [tot] = await conn.query(`
      SELECT SUM(mo.quantity * m.food_cost) AS total
      FROM menu_orders mo
      JOIN menu m ON m.food_id = mo.food_id
      WHERE mo.order_id = ?
    `, [orderId]);

    await conn.commit();
    res.json({ ok: true, orderId, total: Number(tot[0].total || 0) });
  } catch (e) {
    await conn.rollback();
    console.error(e);
    res.status(500).json({ error: e.message || 'Server error' });
  } finally {
    conn.release();
  }
});

// Generic CRUD it can be optional, but gonna keep after the custom route bc they don't shadow them
app.get('/api/:table', async (req, res) => {
  try {
    const [rows] = await dbp.query('SELECT * FROM ??', [req.params.table]);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/:table/:id', async (req, res) => {
  const { table, id } = req.params;
  try {
    const [rows] = await dbp.query('SELECT * FROM ?? WHERE id = ?', [table, id]);
    if (!rows.length) return res.status(404).json({ message: 'Record not found' });
    res.json(rows[0]);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/:table', async (req, res) => {
  const data = req.body;
  const cols = Object.keys(data);
  const vals = Object.values(data);
  try {
    const sql = `INSERT INTO ?? (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`;
    const [r] = await dbp.query(sql, [req.params.table, ...vals]);
    res.status(201).json({ message: 'Record created successfully', id: r.insertId });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/:table/:id', async (req, res) => {
  const { table, id } = req.params;
  const data = req.body;
  try {
    const sets = Object.keys(data).map(k => `${k}=?`).join(', ');
    const vals = Object.values(data);
    const sql = `UPDATE ?? SET ${sets} WHERE id = ?`;
    const [r] = await dbp.query(sql, [table, ...vals, id]);
    if (!r.affectedRows) return res.status(404).json({ message: 'Record not found' });
    res.json({ message: 'Record updated successfully' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/:table/:id', async (req, res) => {
  const { table, id } = req.params;
  try {
    const [r] = await dbp.query('DELETE FROM ?? WHERE id = ?', [table, id]);
    if (!r.affectedRows) return res.status(404).json({ message: 'Record not found' });
    res.json({ message: 'Record deleted successfully' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, () => console.log(`Server running on :${PORT}`));
